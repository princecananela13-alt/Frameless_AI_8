package com.frameless.ai;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/** Frameless_AI launcher: opens the bundled WebUI and gives it a root shell bridge (window.ksu.exec). */
public class MainActivity extends Activity {
    private static final String ENGINE = "/data/adb/modules/frameless_ai/bin/frameless.sh";
    private static final String BG = "#05030B";
    private WebView web;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.parseColor(BG));
        getWindow().setNavigationBarColor(Color.parseColor(BG));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor(BG));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);                 // file:///android_asset is still readable
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        web.addJavascriptInterface(new Bridge(), "ksu");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                // Never leave the bundled page: the page can run root commands.
                return !r.getUrl().toString().startsWith("file:///android_asset/");
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        checkModule();
    }

    /** Warn if root is missing/denied or the Magisk module is not installed. */
    private void checkModule() {
        new Thread(() -> {
            int code = run("[ -f " + ENGINE + " ]", new StringBuilder(), new StringBuilder());
            if (code != 0) {
                final String msg = code == 1
                        ? "Frameless_AI module not found. Flash the module in Magisk and reboot."
                        : "Root access is needed. Allow Frameless_AI in Magisk.";
                runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    /** Runs a command through su. Returns the exit code (or -1 if su could not start). */
    private static int run(String cmd, StringBuilder out, StringBuilder err) {
        try {
            Process p = new ProcessBuilder("su", "-c", cmd).start();
            p.getOutputStream().close();
            final InputStream es = p.getErrorStream();
            final ByteArrayOutputStream eo = new ByteArrayOutputStream();
            Thread t = new Thread(() -> { try { copy(es, eo); } catch (IOException ignored) { } });
            t.start();
            ByteArrayOutputStream oo = new ByteArrayOutputStream();
            copy(p.getInputStream(), oo);
            int code = p.waitFor();
            t.join(2000);
            out.append(oo.toString("UTF-8"));
            err.append(eo.toString("UTF-8"));
            return code;
        } catch (Exception e) {
            err.append(String.valueOf(e));
            return -1;
        }
    }

    private static void copy(InputStream in, ByteArrayOutputStream out) throws IOException {
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }

    /** Same shape as KernelSU's WebUI API: ksu.exec(cmd, optionsJson, callbackName). */
    private class Bridge {
        @JavascriptInterface
        public void exec(final String cmd, final String options, final String cb) {
            if (cmd == null || cb == null || !cb.matches("[A-Za-z0-9_]+")) return;
            new Thread(() -> {
                StringBuilder out = new StringBuilder(), err = new StringBuilder();
                int code = run(cmd, out, err);
                final String js = "window['" + cb + "'](" + code + ","
                        + JSONObject.quote(out.toString()) + "," + JSONObject.quote(err.toString()) + ")";
                runOnUiThread(() -> web.evaluateJavascript(js, null));
            }).start();
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
