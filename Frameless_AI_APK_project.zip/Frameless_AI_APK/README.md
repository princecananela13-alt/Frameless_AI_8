# Frameless_AI launcher (APK source)

Opens the Frameless_AI WebUI in its own app, with root access built in.
Needs: rooted phone + the Frameless_AI Magisk module installed.
The UI shown is the copy bundled in `app/src/main/assets/index.html`.
